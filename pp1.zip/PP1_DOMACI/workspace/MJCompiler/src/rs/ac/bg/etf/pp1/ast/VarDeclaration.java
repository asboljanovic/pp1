// generated with ast extension for cup
// version 0.8
// 7/1/2021 21:22:6


package rs.ac.bg.etf.pp1.ast;

public class VarDeclaration extends VarDecl {

    private Type Type;
    private VarDeclRow VarDeclRow;

    public VarDeclaration (Type Type, VarDeclRow VarDeclRow) {
        this.Type=Type;
        if(Type!=null) Type.setParent(this);
        this.VarDeclRow=VarDeclRow;
        if(VarDeclRow!=null) VarDeclRow.setParent(this);
    }

    public Type getType() {
        return Type;
    }

    public void setType(Type Type) {
        this.Type=Type;
    }

    public VarDeclRow getVarDeclRow() {
        return VarDeclRow;
    }

    public void setVarDeclRow(VarDeclRow VarDeclRow) {
        this.VarDeclRow=VarDeclRow;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(Type!=null) Type.accept(visitor);
        if(VarDeclRow!=null) VarDeclRow.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(Type!=null) Type.traverseTopDown(visitor);
        if(VarDeclRow!=null) VarDeclRow.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(Type!=null) Type.traverseBottomUp(visitor);
        if(VarDeclRow!=null) VarDeclRow.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VarDeclaration(\n");

        if(Type!=null)
            buffer.append(Type.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(VarDeclRow!=null)
            buffer.append(VarDeclRow.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VarDeclaration]");
        return buffer.toString();
    }
}
