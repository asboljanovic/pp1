// generated with ast extension for cup
// version 0.8
// 7/1/2021 21:22:5


package rs.ac.bg.etf.pp1.ast;

public class ConstDeclNum extends ConstDecl {

    private Type Type;
    private String numConstName;
    private Integer N2;
    private ConstDeclMore ConstDeclMore;

    public ConstDeclNum (Type Type, String numConstName, Integer N2, ConstDeclMore ConstDeclMore) {
        this.Type=Type;
        if(Type!=null) Type.setParent(this);
        this.numConstName=numConstName;
        this.N2=N2;
        this.ConstDeclMore=ConstDeclMore;
        if(ConstDeclMore!=null) ConstDeclMore.setParent(this);
    }

    public Type getType() {
        return Type;
    }

    public void setType(Type Type) {
        this.Type=Type;
    }

    public String getNumConstName() {
        return numConstName;
    }

    public void setNumConstName(String numConstName) {
        this.numConstName=numConstName;
    }

    public Integer getN2() {
        return N2;
    }

    public void setN2(Integer N2) {
        this.N2=N2;
    }

    public ConstDeclMore getConstDeclMore() {
        return ConstDeclMore;
    }

    public void setConstDeclMore(ConstDeclMore ConstDeclMore) {
        this.ConstDeclMore=ConstDeclMore;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(Type!=null) Type.accept(visitor);
        if(ConstDeclMore!=null) ConstDeclMore.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(Type!=null) Type.traverseTopDown(visitor);
        if(ConstDeclMore!=null) ConstDeclMore.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(Type!=null) Type.traverseBottomUp(visitor);
        if(ConstDeclMore!=null) ConstDeclMore.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ConstDeclNum(\n");

        if(Type!=null)
            buffer.append(Type.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(" "+tab+numConstName);
        buffer.append("\n");

        buffer.append(" "+tab+N2);
        buffer.append("\n");

        if(ConstDeclMore!=null)
            buffer.append(ConstDeclMore.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ConstDeclNum]");
        return buffer.toString();
    }
}
