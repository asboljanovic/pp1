// generated with ast extension for cup
// version 0.8
// 7/1/2021 21:22:6


package rs.ac.bg.etf.pp1.ast;

public class CondFactTwoExpr extends CondFact {

    private ExprAddopTerm ExprAddopTerm;
    private Relop Relop;
    private ExprAddopTerm ExprAddopTerm1;

    public CondFactTwoExpr (ExprAddopTerm ExprAddopTerm, Relop Relop, ExprAddopTerm ExprAddopTerm1) {
        this.ExprAddopTerm=ExprAddopTerm;
        if(ExprAddopTerm!=null) ExprAddopTerm.setParent(this);
        this.Relop=Relop;
        if(Relop!=null) Relop.setParent(this);
        this.ExprAddopTerm1=ExprAddopTerm1;
        if(ExprAddopTerm1!=null) ExprAddopTerm1.setParent(this);
    }

    public ExprAddopTerm getExprAddopTerm() {
        return ExprAddopTerm;
    }

    public void setExprAddopTerm(ExprAddopTerm ExprAddopTerm) {
        this.ExprAddopTerm=ExprAddopTerm;
    }

    public Relop getRelop() {
        return Relop;
    }

    public void setRelop(Relop Relop) {
        this.Relop=Relop;
    }

    public ExprAddopTerm getExprAddopTerm1() {
        return ExprAddopTerm1;
    }

    public void setExprAddopTerm1(ExprAddopTerm ExprAddopTerm1) {
        this.ExprAddopTerm1=ExprAddopTerm1;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ExprAddopTerm!=null) ExprAddopTerm.accept(visitor);
        if(Relop!=null) Relop.accept(visitor);
        if(ExprAddopTerm1!=null) ExprAddopTerm1.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ExprAddopTerm!=null) ExprAddopTerm.traverseTopDown(visitor);
        if(Relop!=null) Relop.traverseTopDown(visitor);
        if(ExprAddopTerm1!=null) ExprAddopTerm1.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ExprAddopTerm!=null) ExprAddopTerm.traverseBottomUp(visitor);
        if(Relop!=null) Relop.traverseBottomUp(visitor);
        if(ExprAddopTerm1!=null) ExprAddopTerm1.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("CondFactTwoExpr(\n");

        if(ExprAddopTerm!=null)
            buffer.append(ExprAddopTerm.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(Relop!=null)
            buffer.append(Relop.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ExprAddopTerm1!=null)
            buffer.append(ExprAddopTerm1.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [CondFactTwoExpr]");
        return buffer.toString();
    }
}
