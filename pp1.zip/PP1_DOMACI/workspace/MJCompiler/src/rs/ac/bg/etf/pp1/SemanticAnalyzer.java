package rs.ac.bg.etf.pp1;

import org.apache.log4j.Logger;

import rs.ac.bg.etf.pp1.ast.*;
import rs.etf.pp1.symboltable.*;
import rs.etf.pp1.symboltable.concepts.*;

public class SemanticAnalyzer extends VisitorAdaptor {

	// **** IZ RULEVISITOR ****

	int printCallCount = 0;
	int varDeclCount = 0;
	int ternarycnt = 0;

	Logger log = Logger.getLogger(getClass());


	

	// **** IZ RULEVISITOR ****

	private Struct varType = Tab.noType;
    Type currentType = null;
	boolean errorDetected = false;
	Obj currentMethod = null;
	int nVars;

	// **SEMANTICKA ANALIZA**
	
	public boolean passed() {
	
		return !errorDetected;
	}

	
	
	
	
	
	
	public void report_error(String message, SyntaxNode info) {
		errorDetected = true;
		StringBuilder msg = new StringBuilder(message);
		int line = (info == null) ? 0 : info.getLine();
		if (line != 0)
			msg.append(" na liniji ").append(line);
		log.error(msg.toString());
	}

	public void report_info(String message, SyntaxNode info) {
		StringBuilder msg = new StringBuilder(message);
		int line = (info == null) ? 0 : info.getLine();
		if (line != 0)
			msg.append(" na liniji ").append(line);
		log.info(msg.toString());
	}

	// PROGRAM

	public void visit(ProgName progName) {
		progName.obj = Tab.insert(Obj.Prog, progName.getProgName(), Tab.noType);
		Tab.openScope();
		
	}

	public void visit(Program program) {
		if(!nadjenMain) {
			report_error("U programu program ne postoji funkcija main!", null);
		}
		
		nVars = Tab.currentScope().getnVars();
		Tab.chainLocalSymbols(program.getProgName().obj);
		Tab.closeScope();
		

	}

	// TYPE

	public void visit(Type type) {
		if (type.getTypeName().toString().equals("int")) {
			type.struct = Tab.intType;
		}  else if (type.getTypeName().toString().equals("bool")) {
			type.struct = new Struct(Struct.Bool);
		}	
			else if (type.getTypeName().toString().equals("char")) {
				type.struct = Tab.charType;
			
		} else {
			report_error("Greska: Ime " + type.getTypeName() + " ne predstavlja tip!", type);
			type.struct = Tab.noType;
		}
		currentType = type;
		
	}

	// VAR DECLARATIONS


	public void visit(VarDeclaration varDecl) {
		varDeclCount++;
		varType = varDecl.getType().struct;

	}

	public void visit(VarDeclarationPart varDecl) {
		
		Obj obj = Tab.find(varDecl.getVarName());
		if(obj.getAdr() != -1) {
			report_error("Greska na liniji " + varDecl.getLine() + " : Ime '" + varDecl.getVarName()
			+ "' je vec deklarisano! ", null);
			
		} else {

		Obj varNode = Tab.insert(Obj.Var, varDecl.getVarName(), currentType.struct);
	
		report_info("Deklarisana promenljiva " + varDecl.getVarName(), varDecl);
		}
	}
	
	public void visit(VarDeclarationPartArray varDecl) {
		
		Struct temp = new Struct(Struct.Array);
		temp.setElementType(currentType.struct);
		
		Obj varNode = Tab.insert(Obj.Var, varDecl.getVarArrayName(), temp);
		report_info("Deklarisan niz " + varDecl.getVarArrayName(), varDecl);
		
	}

	// CONST

	public void visit(ConstDeclNum constDecl) {
		Obj obj = Tab.find(constDecl.getNumConstName());
		if(obj.getAdr() != -1) {
			report_error("Greska na liniji " + constDecl.getLine() + " : Ime '" + constDecl.getNumConstName()
			+ "' je vec deklarisano! ", null);
			
		} else {
		report_info("Deklarisana konstanta " + constDecl.getNumConstName(), constDecl);
		Obj constNode = Tab.insert(Obj.Con, constDecl.getNumConstName(), constDecl.getType().struct);
		constNode.setAdr(constDecl.getN2());
		report_info("Vrednost numericke konstante je " + constDecl.getN2(), constDecl);
		}
	}

	public void visit(ConstDeclChar constDecl) {
		Obj obj = Tab.find(constDecl.getCharConstName());
		if(obj.getAdr() != -1) {
			report_error("Greska na liniji " + constDecl.getLine() + " : Ime '" + constDecl.getCharConstName()
			+ "' je vec deklarisano! ", null);
			
		} else {
		report_info("Deklarisana konstanta " + constDecl.getCharConstName(), constDecl);
		Obj constNode = Tab.insert(Obj.Con, constDecl.getCharConstName(), constDecl.getType().struct);
		constNode.setAdr(constDecl.getC2());
		report_info("Vrednost karakter konstante je " + constDecl.getC2(), constDecl);
		}
	}

	public void visit(ConstDeclBool constDecl) {
		Obj obj = Tab.find(constDecl.getBoolConstName());
		if(obj.getAdr() != -1) {
			report_error("Greska na liniji " + constDecl.getLine() + " : Ime '" + constDecl.getBoolConstName()
			+ "' je vec deklarisano! ", null);
			
		} else {
		report_info("Deklarisana konstanta " + constDecl.getBoolConstName(), constDecl);
		Obj constNode = Tab.insert(Obj.Con, constDecl.getBoolConstName(), constDecl.getType().struct);
		if (constDecl.getB2()) {
			constNode.setAdr(1);
		} else
			constNode.setAdr(0);
		report_info("Vrednost bool konstante je " + constDecl.getB2(), constDecl);
		}
	}

	public void visit(ConstDeclMoreNum constDecl) {
		Obj obj = Tab.find(constDecl.getNumConstName());
		if(obj.getAdr() != -1) {
			report_error("Greska na liniji " + constDecl.getLine() + " : Ime '" + constDecl.getNumConstName()
			+ "' je vec deklarisano! ", null);
			
		} else {
		report_info("Deklarisana konstanta " + constDecl.getNumConstName(), constDecl);
		Obj constNode = Tab.insert(Obj.Con, constDecl.getNumConstName(), currentType.struct);
		constNode.setAdr(constDecl.getN1());
		report_info("Vrednost numericke konstante je " + constDecl.getN1(), constDecl);
		}
	}

	public void visit(ConstDeclMoreChar constDecl) {
		Obj obj = Tab.find(constDecl.getCharConstName());
		if(obj.getAdr() != -1) {
			report_error("Greska na liniji " + constDecl.getLine() + " : Ime '" + constDecl.getCharConstName()
			+ "' je vec deklarisano! ", null);
			
		} else {
		report_info("Deklarisana konstanta " + constDecl.getCharConstName(), constDecl);
		Obj constNode = Tab.insert(Obj.Con, constDecl.getCharConstName(), currentType.struct);
		constNode.setAdr(constDecl.getC1());
		report_info("Vrednost karakter konstante je " + constDecl.getC1(), constDecl);
		}
	}

	public void visit(ConstDeclMoreBool constDecl) {
		Obj obj = Tab.find(constDecl.getBoolConstName());
		if(obj.getAdr() != -1) {
			report_error("Greska na liniji " + constDecl.getLine() + " : Ime '" + constDecl.getBoolConstName()
			+ "' je vec deklarisano! ", null);
			
		} else {
		report_info("Deklarisana konstanta " + constDecl.getBoolConstName(), constDecl);
		Obj constNode = Tab.insert(Obj.Con, constDecl.getBoolConstName(), currentType.struct);
		if (constDecl.getB1()) {
			constNode.setAdr(1);
		} else
			constNode.setAdr(0);
		report_info("Vrednost bool konstante je " + constDecl.getB1(), constDecl);
		}
	}

	// METHOD

	public void visit(MethodTypeName methodTypeName) {
		
		if (methodTypeName.getMethodName().equals("main")) {
			
			nadjenMain = true; 
		}
		currentMethod = Tab.insert(Obj.Meth, methodTypeName.getMethodName(), methodTypeName.getType().struct);
		methodTypeName.obj = currentMethod;
		Tab.openScope();
		report_info("Obradjuje se funkcija " + methodTypeName.getMethodName(), methodTypeName);

	}
	
	public void visit(MethodTypeNameVoid methodTypeName) {
		
		if (methodTypeName.getMethodName().equals("main")) {
			
			nadjenMain = true; 
		}
		currentMethod = Tab.insert(Obj.Meth, methodTypeName.getMethodName(), new Struct(0));
		methodTypeName.obj = currentMethod;
		Tab.openScope();
		report_info("Obradjuje se funkcija " + methodTypeName.getMethodName(), methodTypeName);

	}
	
	boolean nadjenMain = false;

	public void visit(MethodDeclaration methodDecl) {
	
		Tab.chainLocalSymbols(currentMethod);
		Tab.closeScope();
		currentMethod = null;

	}

	public void visit(MethodDeclarationVoid methodDecl) {
	
		Tab.chainLocalSymbols(currentMethod);
		Tab.closeScope();
		report_info("Deklarisana procedura " + currentMethod.getName(), methodDecl);

		currentMethod = null;
		
	}
	
	

	// ACT PARAMS ---------- B NIVO

	// DESIGNATOR

	public void visit(DesignatorSingle designator) {
		Obj obj = Tab.find(designator.getDesName());
		if (obj == Tab.noObj) {
			report_error("Greska na liniji " + designator.getLine() + " : ime " + designator.getDesName()
					+ " nije deklarisano! ", null);
		}
		designator.obj = obj;

	}

	int povratnaVrednost = 0;
	
	public void visit(DesignatorExpr designator) {
		String objName = designator.getDesArrayName().getDesArrayName();
		Obj obj = Tab.find(objName);
		
		if (obj.getType().getKind() != Struct.Array) {
			report_error("Greska na liniji " + designator.getLine() + ", " + objName + " nije deklarisan kao niz.", null);
		} 		
		
		if (obj == Tab.noObj) {
			report_error("Greska na liniji " + designator.getLine() + " : ime " + objName
					+ " nije deklarisano! ", null);
		}
		if(designator.getExpr().struct.getKind() == Struct.Array) {
			povratnaVrednost = designator.getExpr().struct.getElemType().getKind();
	
			
			
		}
		
		designator.obj = obj;

	}
	
	public void visit(DesArrayName desArray) {
		Obj obj = Tab.find(desArray.getDesArrayName());
    	if (obj == Tab.noObj) {
    		report_error("Ne postoji designator sa imenom : " + desArray.getDesArrayName(), null);
    	}
    	 desArray.obj = obj;
    }
	
	
	
					//TERM
	
	public void visit(TermFactor term) {
		term.struct = term.getFactor().struct;
	}
	
	public void visit(TermMulop term) {
		Struct t = term.getTerm().struct;
		Struct f = term.getFactor().struct;
		
		if(t.getKind() == Struct.Array && f.getKind() != Struct.Array) {
			if(t.getElemType().getKind() != f.getKind() ) { 
				report_error("Greska na liniji " + term.getLine() + " : nekompatibilni tipovi.", null);
			term.struct = Tab.noType;
			}
		} else if(t.getKind() != Struct.Array && f.getKind() == Struct.Array) {
			if(f.getElemType().getKind() != t.getKind() ) { 
				report_error("Greska na liniji " + term.getLine() + " : nekompatibilni tipovi.", null);
			term.struct = Tab.noType;
			}
			
		} else if(t.getKind() == Struct.Array && f.getKind() == Struct.Array) {
			if(f.getElemType().getKind() != t.getElemType().getKind() ) { 
				report_error("Greska na liniji " + term.getLine() + " : nekompatibilni tipovi.", null);
			term.struct = Tab.noType;
			}
		} else if(t.getKind() != Struct.Array && f.getKind() != Struct.Array) {
			if(t.getKind() != f.getKind()) {
			report_error("Greska na liniji " + term.getLine() + " : nekompatibilni tipovi.", null);
			term.struct = Tab.noType;
		}
		}
		

		
		
		term.struct = term.getFactor().struct;
	}
	
				//EXPRESSION
	
	
	public void visit(TermExpr exp) {
		
		exp.struct = exp.getTerm().struct;
	}
	
	public void visit(SubTermExpr exp) {
		Struct expStruct = exp.getTerm().struct;
			if(expStruct == Tab.intType) {
				exp.struct = expStruct;
			}else {
	  			report_error("Greska na liniji " + exp.getLine() + " : nekompatibilni tipovi u izrazu. Minus se moze dodeliti samo INT vrednosti."
	  					, null);
	  				}
	}
	
	public void visit(ExprAddopTermDecl exp) {
		Struct te = exp.getExprAddopTerm().struct;
  		Struct t = exp.getTerm().struct;
  		exp.struct = te;
  		
  		if(te.getKind() == Struct.Array && t.getKind() == Struct.Array) {
  			if(!te.assignableTo(t)) {
  				report_error("Greska na liniji " + exp.getLine() + " : nekompatibilni tipovi u izrazu."
  	  					, null);
  	  			exp.struct = Tab.noType; 
  	  			
  			}
  		} else if(te.getKind() == Struct.Array && t.getKind() != Struct.Array) {
  			if(te.getElemType().getKind() != t.getKind()) {
  				report_error("Greska na liniji " + exp.getLine() + " : nekompatibilni tipovi u izrazu."
  	  					, null);
  	  			exp.struct = Tab.noType; 
  			}
  		} else if(te.getKind() != Struct.Array && t.getKind() == Struct.Array) {
  			if(t.getElemType().getKind() != te.getKind()) {
  				report_error("Greska na liniji " + exp.getLine() + " : nekompatibilni tipovi u izrazu."
  	  					, null);
  	  			exp.struct = Tab.noType; 
  			}
  		} else if(te.getKind() != Struct.Array && t.getKind() != Struct.Array) {
  			if (te.equals(t) && te == Tab.intType)
  	  			exp.struct = te;
  	  		else {
  	  			report_error("Greska na liniji " + exp.getLine() + " : nekompatibilni tipovi u izrazu."
  	  					, null);
  	  			exp.struct = Tab.noType;
  	  		}
  			
  		}
  		
  	
		
	}
	
	
	public void visit(AddopTermExpr exp) {
		exp.struct = exp.getExprAddopTerm().struct;
	}
	
	public void visit(Expr1Decl exp) {
		exp.struct = exp.getExpr().struct;
	}
	public void visit(Expr2Decl exp) {
		exp.struct = exp.getExpr().struct;
		
	}
	
	
	public void visit(TernaryExpr tern) {
		ternarycnt++;
		Struct exp1 = tern.getExprAddopTerm1().struct;
		Struct exp2 = tern.getExprAddopTerm2().struct;
		Struct cond = tern.getExprAddopTerm().struct;
		
		if(cond.getKind() == Struct.Array) {
			if(cond.getElemType().getKind() != Struct.Int && 
					cond.getElemType().getKind() != Struct.Bool) {
				report_error("Greska na liniji " + tern.getLine() + " : uslov mora biti tipa int ili bool!"
	  					, null);
				tern.struct = Tab.noType;
			}
		} else if(cond.getKind() != Struct.Int && 
				cond.getKind() != Struct.Bool) {
			report_error("Greska na liniji " + tern.getLine() + " : uslov mora biti tipa int ili bool!"
  					, null); tern.struct = Tab.noType;
		}

		if(exp1.getKind() == Struct.Array && exp2.getKind() != Struct.Array) {
			if(exp1.getElemType().getKind() == exp2.getKind()) {
				tern.struct =exp2;
			}else {
				report_error("Greska na liniji " + tern.getLine() + " : nekompatibilni tipovi u ternarnom izrazu"
	  					, null);
				tern.struct = Tab.noType;
			}
		} else if(exp1.getKind() != Struct.Array && exp2.getKind() == Struct.Array) {
			if(exp2.getElemType().getKind() == exp1.getKind()) {
				tern.struct =exp1;
			} else { report_error("Greska na liniji " + tern.getLine() + " : nekompatibilni tipovi u ternarnom izrazu"
  					, null); tern.struct = Tab.noType; }
		} else if(exp1.getKind() == Struct.Array && exp2.getKind() == Struct.Array) {
			if(exp1.getElemType().getKind() == exp2.getElemType().getKind()) {
				tern.struct = exp1.getElemType();
			} else { report_error("Greska na liniji " + tern.getLine() + " : nekompatibilni tipovi u ternarnom izrazu"
  					, null); tern.struct = Tab.noType;}
		} else	if(exp1.equals(exp2)) {
				tern.struct =exp1;
			}	else {
	  			report_error("Greska na liniji " + tern.getLine() + " : nekompatibilni tipovi u ternarnom izrazu"
	  					, null);
	  			tern.struct = Tab.noType;
	  		}
	}
	
	
					//CONDITION FACT
	
	public void visit(CondFactSingleExpr cond) {
//		Struct ex = cond.getExprAddopTerm().struct;
//		if(ex.getKind() == Struct.Bool) {
//			cond.struct = new Struct(Struct.Bool);
//		} else if(ex.getKind() == Struct.Int) {
//			cond.struct = Tab.intType;
//		} else if(ex.getKind() == Struct.Array) {
//			if(ex.getElemType().getKind() == Struct.Bool) {
//				cond.struct = new Struct(Struct.Bool);
//			} else if(ex.getElemType().getKind() == Struct.Int) {
//				cond.struct = new Struct(Struct.Int);
//			}
//		}
//		
//		else 	report_error("Greska na liniji " + cond.getLine() + ". Uslov mora biti tipa INT ili BOOL.", null);		
	}
	
	public void visit(CondFactTwoExpr cond) {
		Struct ex1 = cond.getExprAddopTerm().struct;
		Struct ex2 = cond.getExprAddopTerm1().struct;
		if (ex1.equals(ex2)) {
			cond.struct = new Struct(Struct.Bool);
		} else {
			report_error("Greska na liniji " + cond.getLine() + ". Nekompatibilni tipovi.", null);
			cond.struct = Tab.noType;
		}

	}
	
	
						//FACTOR bez funkcija
	
	
	public void visit(FactorDesignator des) { 		
		des.struct = des.getDesignator().obj.getType();		
	}
	
	public void visit(FactorNumConst f) {
		f.struct = Tab.intType;
	}
	
	public void visit(FactorCharConst f) {
		f.struct = Tab.charType;
		
		
		
	}
	public void visit(FactorBoolConst f) {
		f.struct = new Struct(Struct.Bool);		
	}
	public void visit(FactorNewType f) {
		f.struct = f.getType().struct;	
		
	}
	
	Struct newOp = Tab.noType;
	
	public void visit(FactorNewTypeWithExpr f) {
		f.struct = new Struct(Struct.Array);
		f.struct.setElementType(f.getType().struct);
		if(f.getExpr().struct.getKind() != Struct.Int) {
			report_error("Greska na liniji " + f.getLine() + " : " + "velicina niza mora biti int tipa! ", null);		
		}else 		
	    newOp = f.getType().struct;
		
	}
	
	public void visit(FactorExpr f) {
		f.struct = f.getExpr().struct;
	}
	
	
					//DESIGNATOR STATEMENTS
	
	public void visit(DesignatorInc inc) {
		Obj des = inc.getDesignator().obj;
			
			if (des.getType().getKind() == Struct.Array) {
				if(des.getType().getElemType().getKind() != Struct.Int) {
					report_error("Inkrementiranje ne-int promenljive " + des.getName() + " na liniji " + inc.getLine(), null);
				}
				 else report_info("Inkrementiranje int promenjive " + des.getName() + " na liniji " + inc.getLine(), null);
			} else if(des.getType().getKind() != Struct.Int) {
				report_error("Inkrementiranje ne-int promenljive " + des.getName() + " na liniji " + inc.getLine(), null);
			} else {
				report_info("Inkrementiranje int promenjive " + des.getName() + " na liniji " + inc.getLine(), null);
			}
				
		
	}
	
	public void visit(DesignatorDec dec) {
		Obj des = dec.getDesignator().obj;
		
		if (des.getType().getKind() == Struct.Array) {
			if(des.getType().getElemType().getKind() != Struct.Int) {
				report_error("Dekrementiranje ne-int promenljive " + des.getName() + " na liniji " + dec.getLine(), null);
			}
			 else report_info("Dekrementiranje int promenjive " + des.getName() + " na liniji " + dec.getLine(), null);
		} else if(des.getType().getKind() != Struct.Int) {
			report_error("Dekrementiranje ne-int promenljive " + des.getName() + " na liniji " + dec.getLine(), null);
		} else {
			report_info("Dekrementiranje int promenjive " + des.getName() + " na liniji " + dec.getLine(), null);
		}
	}
	

	public void visit(DesignatorAssign des) {
			
			Obj obj = des.getDesignator().obj;
			Struct t = Tab.noType;
			
			
			
				if(obj.getType().getKind() == Struct.Array) { //pristup nizu
					 if(obj.getType().getElemType().getKind() == newOp.getKind()) {
						report_info("Uspesno izvrsena new operacija  " , des);
						newOp = Tab.noType;
					 }	else if(des.getExpr().struct.getKind() == Struct.Array) {
						 	if(obj.getType().getElemType().assignableTo(des.getExpr().struct.getElemType())) {
						 		
							report_info("Uspesno izvrsena dodela vrednosti  " , des); } else {
								report_error("Greska na liniji " + des.getLine() + " : " + "nekompatibilni tipovi u dodeli vrednosti! ", null);
								
							}
						
					}else if(des.getExpr().struct.getKind() !=Struct.Array && 
							des.getExpr().struct.getKind()  == 	obj.getType().getElemType().getKind() 
							) {
						
						report_info("Uspesno izvrsena dodela vrednosti  " , des);
						
					} else report_error("Greska na liniji " + des.getLine() + " : " + "nekompatibilni tipovi u dodeli vrednosti! ", null);
					
				} else if(des.getExpr().struct.getKind() == Struct.Array) {
					if(obj.getType().getKind() == des.getExpr().struct.getElemType().getKind() ) 
						report_info("Uspesno izvrsena  operacija dodele  " , des);
					else	report_error("Greska na liniji " + des.getLine() + " : " + "nekompatibilni tipovi u dodeli vrednosti! ", null);
					
				} else if (obj.getType().getKind() == des.getExpr().struct.getKind()) {
					report_info("Uspesno izvrsena dodela vrednosti na liniji " + des.getLine()  , des);
				} else report_error("Greska na liniji " + des.getLine() + " : " + "nekompatibilni tipovi u dodeli vrednosti! ", null);

	}
	
	
				//STATEMENTS
	
	public void visit(PrintStatement ps) {
		printCallCount++;
		
		if(ps.getExpr().struct != Tab.intType && ps.getExpr().struct!= Tab.charType
    			&& ps.getExpr().struct.getKind() != Struct.Array && ps.getExpr().struct.getKind() != Struct.Bool) 
    		report_error ("Semanticka greska na liniji " + ps.getLine() + ": Operand instrukcije PRINT mora biti char, int ili bool tipa", null );
		else report_info("Uspesno izvrsena operacija print  " , ps);
		
	}
	
	public void visit(PrintStatementWithComma ps) {
		
		if(ps.getExpr().struct != Tab.intType && ps.getExpr().struct!= Tab.charType
    			
				&& ps.getExpr().struct.getKind() != Struct.Array && ps.getExpr().struct.getKind() != Struct.Bool ) 
		
			report_error ("Semanticka greska na liniji " + ps.getLine() + ": Operand instrukcije PRINT je nedozvoljenog tipa!", null );
		
		else if (ps.getNum().intValue() <= 0)
			report_error ("Semanticka greska na liniji " + ps.getLine() + ": Broj ponavljanja ne moze biti manji ili jednak 0!", null );
		else {
			report_info("Uspesno izvrsena operacija print  " , ps);
		}
	}
	
	public  void visit(ReadStatement read) {
		if(read.getDesignator().obj.getLevel() != -1) {
			if(read.getDesignator().obj.getType().getKind() == Struct.Array) {
				if(read.getDesignator().obj.getType().getElemType().getKind() != Struct.Char
    			 && read.getDesignator().obj.getType().getElemType().getKind() != Struct.Int
    			 && read.getDesignator().obj.getType().getElemType().getKind() != Struct.Bool) {
					report_error ("Semanticka greska na liniji " + read.getLine() + ": Operand instrukcije READ mora biti char, bool ili int tipa", null );
				}
			} else if(read.getDesignator().obj.getType() != Tab.intType && read.getDesignator().obj.getType() != Tab.charType
	    			&& read.getDesignator().obj.getType().getKind() != Struct.Bool) 
    		report_error ("Semanticka greska na liniji " + read.getLine() + ": Operand instrukcije READ mora biti char, bool ili int tipa", null );
		else report_info("Uspesno izvrsena operacija read  " , read);
		}
	}
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	 
	
	
	
	
	
	
	
	
	
	
	

}
