package rs.ac.bg.etf.pp1;

import rs.ac.bg.etf.pp1.ast.*;
import rs.etf.pp1.mj.runtime.Code;

import java.util.ArrayList;

import rs.ac.bg.etf.pp1.CounterVisitor.*;
import rs.etf.pp1.symboltable.*;
import rs.etf.pp1.symboltable.concepts.*;



public class CodeGenerator extends VisitorAdaptor {

	private int mainPc;
	private int cond=0;

	private int fix1;
	private int fix2;
	
	public int getMainPc() {
		return mainPc;
	}
	
	
	
				//METODE
	
	
	// int, char metode NE TREBA ZA A
	public void visit(MethodTypeName method) {
		if("main".equalsIgnoreCase(method.getMethodName())){			
			mainPc = Code.pc;
		}
		method.obj.setAdr(Code.pc);
		// Collect arguments and local variables
		SyntaxNode methodNode = method.getParent();
	
		VarCounter varCnt = new VarCounter();
		methodNode.traverseTopDown(varCnt);
		
		FormParamCounter fpCnt = new FormParamCounter();
		methodNode.traverseTopDown(fpCnt);
		
		// Generate the entry
		Code.put(Code.enter);
		Code.put(fpCnt.getCount());
		Code.put(fpCnt.getCount() + varCnt.getCount());
	}
	
	
	// void metoda 
	public void visit(MethodTypeNameVoid method) {
		if("main".equalsIgnoreCase(method.getMethodName())){			
			mainPc = Code.pc;
		}
		method.obj.setAdr(Code.pc);
		// Collect arguments and local variables
		SyntaxNode methodNode = method.getParent();
	
		VarCounter varCnt = new VarCounter();
		methodNode.traverseTopDown(varCnt);
		
		FormParamCounter fpCnt = new FormParamCounter();
		methodNode.traverseTopDown(fpCnt);
		
		// Generate the entry
		Code.put(Code.enter);
		Code.put(fpCnt.getCount());
		Code.put(fpCnt.getCount() + varCnt.getCount());
	}
	
	public void visit(MethodDeclarationVoid methodDecl){
		Code.put(Code.exit);
		Code.put(Code.return_);
	}
	
						//STATEMENTS
	
	
	public void visit(PrintStatement prt) {
		
			if (prt.getExpr().struct == Tab.intType) { //int
					Code.loadConst(5);
					Code.put(Code.print);
			} else if (prt.getExpr().struct.getKind() == Struct.Array) {
				if (prt.getExpr().struct.getElemType() == Tab.intType 
						|| prt.getExpr().struct.getElemType().getKind() == Struct.Bool ) {
					Code.loadConst(5);
					Code.put(Code.print);
				} else if (prt.getExpr().struct.getElemType() == Tab.charType) {
					Code.loadConst(1);
					Code.put(Code.bprint);
				} 
			}
			else if (prt.getExpr().struct == Tab.charType) { //char
				
					Code.loadConst(1);
					Code.put(Code.bprint);
			} else {
				Code.loadConst(5);
				Code.put(Code.print);
			}

		
		
	}
	
	public void visit(PrintStatementWithComma ps) {
		int brojPrintova = ps.getNum().intValue();
		
		if(ps.getExpr().struct.getKind() == Struct.Array) {
			if(ps.getExpr().struct.getElemType().getKind() == Struct.Int || 
					ps.getExpr().struct.getElemType().getKind() == Struct.Bool) {
				for(int i = 0 ; i < brojPrintova; i++) {
					Code.put(Code.dup);
					Code.loadConst(5);
					Code.put(Code.print);
				}
			} else {
				for(int i = 0 ; i < brojPrintova; i++) {
					Code.put(Code.dup);
					Code.loadConst(1);
					Code.put(Code.bprint);
				}
			
				
			}
				
		}
		
		else if (ps.getExpr().struct == Tab.intType || ps.getExpr().struct.getKind() == Struct.Bool  ) {
		
			for(int i = 0 ; i < brojPrintova; i++) {
				Code.put(Code.dup);
				Code.loadConst(5);
				Code.put(Code.print);
			}
		
		} else {
			
			
			for(int i = 0 ; i < brojPrintova; i++) {
				Code.put(Code.dup);
				Code.loadConst(1);
				Code.put(Code.bprint);
			}
		
			
		}
		
	}
	
	public void visit(ReadStatement read) {
	
		 if (read.getDesignator().obj.getType().getKind() == Struct.Array) {
			if(read.getDesignator().obj.getType().getElemType() == Tab.charType) {
				 Code.put(Code.bread);
				 Code.put(Code.astore);
			
			} else {
				 Code.put(Code.read);
				 Code.put(Code.astore);
				
			}
			 
		} else  
	 if (read.getDesignator().obj.getType() == Tab.charType) {
         Code.put(Code.bread);
     	Code.store(read.getDesignator().obj);
     } else {
         Code.put(Code.read);
     	Code.store(read.getDesignator().obj);
     }
		
	 
	}
	
	
				// FACTOR
	int arraySize;
	
	
	public void visit(ConstDeclBool constDecl) {
		
	
	}
	
	public void visit(ConstDeclMoreBool constDecl) {
		
		
	}
	public void visit(ConstDeclNum constDecl) {
		
				
		
	}
	public void visit(ConstDeclMoreNum constDecl) {
	
				
		
	}
	
	
	
	public void visit(FactorNumConst fnc) {
		
			Code.loadConst(fnc.getN1().intValue());
		
	}

	public void visit(FactorCharConst fnc) {
		Code.loadConst(fnc.getC1().charValue());
		}
	

	
	public void visit(FactorBoolConst fbc) {
		 if(fbc.getB1().toString().equals("true")) {
			Code.loadConst(1);
		} else Code.loadConst(0);
		
		
	}
	
	boolean newExpr;
	
	public void visit(FactorNewTypeWithExpr fnt) {
		
		Code.put(Code.newarray);
		Code.put(1);
		newExpr = true;
		
	}
	
	public void visit(FactorExpr fe) {
		
	}
	
	public void visit(TernaryExpr tern) {

	}
	
	
	
			//DESIGNATOR
	
	String trenutnoIme = "";
	
			public void visit(DesignatorSingle des) {
				SyntaxNode parent = des.getParent();
				
		
				
			
				 if (DesignatorAssign.class != parent.getClass() && DesignatorNoActPars.class != parent.getClass()
						&& DesignatorWithActPars.class != parent.getClass() && DesignatorInc.class != parent.getClass()
						&& DesignatorDec.class != parent.getClass()
						&& FactorDesignatorNoParams.class != parent.getClass()
						&& FactorDesignatorWithParams.class != parent.getClass()) {
					Code.load(des.obj);
				}
			}
	
	public void visit(DesignatorExpr des) {
		
		SyntaxNode parent = des.getParent();
		if(FactorDesignator.class == parent.getClass()) {
			Code.put(Code.aload);
		}
	
		
	}
	
	public void visit(DesArrayName des) { //uzmi adresu niza
		   Obj object = des.obj;
		   Code.load(object);
	}
	

	
	
	
			//DESIGNATOR STATEMENT
	
	
	public void visit(DesignatorAssign des) {
		if (newExpr == true) { // ako je operacija new storuj niz
			Code.store(des.getDesignator().obj);
			newExpr = false;
		}else if(des.getDesignator().obj.getType().getKind() == Struct.Array) {
			Code.put(Code.astore);
			
		}else 
		{
		Code.store(des.getDesignator().obj);
	}
		
		
	}
	
	
	public void visit(DesignatorInc des) {
		
		if(des.getDesignator().obj.getType().getKind() != Struct.Array) {
		if(des.getDesignator().getClass() == DesignatorExpr.class) {
			Code.loadConst(1);
			Code.put(Code.add);
			Code.put(Code.astore);
			
		}else {
			Code.load(des.getDesignator().obj);
			Code.loadConst(1);
			Code.put(Code.add);
			Code.store(des.getDesignator().obj);
		} }
		else {
			if(des.getDesignator().getClass() == DesignatorExpr.class) {
				Code.put(Code.dup2);
				Code.put(Code.aload);
				Code.loadConst(1);
				Code.put(Code.add);
				Code.put(Code.astore);
				
			}else {
				Code.load(des.getDesignator().obj);
				Code.loadConst(1);
				Code.put(Code.add);
				Code.store(des.getDesignator().obj);
			}
			
		}
	}
	

	public void visit(DesignatorDec des) {
		if(des.getDesignator().obj.getType().getKind() != Struct.Array) {
		if(des.getDesignator().getClass() == DesignatorExpr.class) {
			Code.loadConst(1);
			Code.put(Code.sub);
			Code.put(Code.astore);
			
		}else {
			Code.load(des.getDesignator().obj);
			Code.loadConst(1);
			Code.put(Code.sub);
			Code.store(des.getDesignator().obj);
		} } else {
			if(des.getDesignator().getClass() == DesignatorExpr.class) {
				Code.put(Code.dup2);
				Code.put(Code.aload);
				Code.loadConst(1);
				Code.put(Code.sub);
				Code.put(Code.astore);
				
			}else {
				Code.load(des.getDesignator().obj);
				Code.loadConst(1);
				Code.put(Code.add);
				Code.store(des.getDesignator().obj);
			}
			
		}
	}
	
	//MULOP
	ArrayList<String> mulop = new ArrayList<String>();
	
	
	public void visit(MulOperator mul) {
		mulop.add("mul");
	}
	public void visit(DivOperator mo) {
		mulop.add("div");
	}
	public void visit(ModOperator mo) {
		mulop.add("mod");
}
	
	public void visit(TermMulop term) {
		
			if(mulop.get(mulop.size() - 1) == "mul") {
				
						Code.put(Code.mul);
			
				
				
								
			}else if(mulop.get(mulop.size() - 1) == "div") {
				
						Code.put(Code.div);
			
			
				
			}else if(mulop.get(mulop.size() - 1) == "mod") {
				
					Code.put(Code.rem);
				
				
			
			}
			mulop.remove(mulop.size() - 1);
	}
	
	//ADOP
	
	ArrayList<String> addop= new ArrayList<String>();
	
	public void visit(AddOperator ad) {
		addop.add("add");
	}
	
    public void visit(SubOperator sub) {
    	addop.add("sub");
	}
	
    public void visit(TermExpr e) {

   
		if(e.getParent().getClass() == TernaryExpr.class ) {
			if(cond==0) {
				Code.loadConst(0);
				Code.putFalseJump(Code.gt, 0);
				fix1=Code.pc-2;
				cond++;
				return;
			}
			if(cond==1) {
				cond++;
				Code.putJump(0);
				fix2=Code.pc-2;
				Code.fixup(fix1);
				return;
			}
			if(cond==2) {
				Code.fixup(fix2);
				cond=0;
				return;
			}
		}
    	
    }
    
    public void visit(SubTermExpr sub) {
    	Code.put(Code.neg);
    	

		if( sub.getParent().getClass() == TernaryExpr.class) {
			if(cond==0) {
				Code.loadConst(0);
				Code.putFalseJump(Code.gt, 0);
				fix1=Code.pc-2;
				cond++;
				return;
			}
			if(cond==1) {
				cond++;
				Code.putJump(0);
				fix2=Code.pc-2;
				Code.fixup(fix1);
				return;
			}
			if(cond==2) {
				Code.fixup(fix2);
				cond=0;
				return;
			}
		}
		
    	
    	
    }
    
	
	public void visit(ExprAddopTermDecl e) {
		if (addop.get(addop.size() - 1) == "add") {

				Code.put(Code.add);
			
		} else if (addop.get(addop.size() - 1) == "sub") {
		
				Code.put(Code.sub);
			

		

		}
		addop.remove(addop.size() - 1);
		

	
		if( e.getParent().getClass() == TernaryExpr.class) {
			if(cond==0) {
				Code.loadConst(0);
				Code.putFalseJump(Code.gt, 0);
				fix1=Code.pc-2;
				cond++;
				return;
			}
			if(cond==1) {
				cond++;
				Code.putJump(0);
				fix2=Code.pc-2;
				Code.fixup(fix1);
				return;
			}
			if(cond==2) {
				Code.fixup(fix2);
				cond=0;
				return;
			}
		}

	}

			//RELOP
	
	ArrayList<String> relop= new ArrayList<String>();
	
	public void visit(IfEqualsOp eq) {
		relop.add("==");
	}
	public void visit(IfNotEquals eq) {
		relop.add("!=");
	}
	public void visit(GreaterThanOp eq) {
		relop.add(">");
	}
	public void visit(GreaterThanOrEqualOp eq) {
		relop.add(">=");
	}
	public void visit(LessThanOp eq) {
		relop.add("<");
	}
	public void visit(LessThanOrEqual eq) {
		relop.add("<=");
	}
	
	
	// cond fact
	
	public void visit(CondFactSingleExpr cond) {
		

	}
	
	public void visit(CondFactTwoExpr cond) {
		int op = Code.eq;
		if(relop.get(relop.size() - 1) == "==") {
			op = Code.eq;
					}
		else if(relop.get(relop.size() - 1) == "!=") {
			op = Code.ne;
		}	else if(relop.get(relop.size() - 1) == ">") {
			op = Code.gt;
		}	else if(relop.get(relop.size() - 1) == ">=") {
			op = Code.ge;
		}	else if(relop.get(relop.size() - 1) == "<") {
			op = Code.lt;
		}	else if(relop.get(relop.size() - 1) == "<=") {
			op = Code.le;
		}
		relop.remove(relop.size() - 1);
		
		Code.putFalseJump(op, 0);
		
	}
	
	
	
	
}
