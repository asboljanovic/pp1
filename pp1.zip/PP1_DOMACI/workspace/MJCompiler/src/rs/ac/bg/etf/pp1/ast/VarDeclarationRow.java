// generated with ast extension for cup
// version 0.8
// 7/1/2021 21:22:6


package rs.ac.bg.etf.pp1.ast;

public class VarDeclarationRow extends VarDeclRow {

    private VarDeclRow VarDeclRow;
    private VarDeclRowPart VarDeclRowPart;

    public VarDeclarationRow (VarDeclRow VarDeclRow, VarDeclRowPart VarDeclRowPart) {
        this.VarDeclRow=VarDeclRow;
        if(VarDeclRow!=null) VarDeclRow.setParent(this);
        this.VarDeclRowPart=VarDeclRowPart;
        if(VarDeclRowPart!=null) VarDeclRowPart.setParent(this);
    }

    public VarDeclRow getVarDeclRow() {
        return VarDeclRow;
    }

    public void setVarDeclRow(VarDeclRow VarDeclRow) {
        this.VarDeclRow=VarDeclRow;
    }

    public VarDeclRowPart getVarDeclRowPart() {
        return VarDeclRowPart;
    }

    public void setVarDeclRowPart(VarDeclRowPart VarDeclRowPart) {
        this.VarDeclRowPart=VarDeclRowPart;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(VarDeclRow!=null) VarDeclRow.accept(visitor);
        if(VarDeclRowPart!=null) VarDeclRowPart.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(VarDeclRow!=null) VarDeclRow.traverseTopDown(visitor);
        if(VarDeclRowPart!=null) VarDeclRowPart.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(VarDeclRow!=null) VarDeclRow.traverseBottomUp(visitor);
        if(VarDeclRowPart!=null) VarDeclRowPart.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VarDeclarationRow(\n");

        if(VarDeclRow!=null)
            buffer.append(VarDeclRow.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(VarDeclRowPart!=null)
            buffer.append(VarDeclRowPart.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VarDeclarationRow]");
        return buffer.toString();
    }
}
