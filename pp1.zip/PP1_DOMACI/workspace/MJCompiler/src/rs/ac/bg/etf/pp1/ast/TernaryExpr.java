// generated with ast extension for cup
// version 0.8
// 7/1/2021 21:22:6


package rs.ac.bg.etf.pp1.ast;

public class TernaryExpr extends Expr {

    private ExprAddopTerm ExprAddopTerm;
    private ExprAddopTerm ExprAddopTerm1;
    private ExprAddopTerm ExprAddopTerm2;

    public TernaryExpr (ExprAddopTerm ExprAddopTerm, ExprAddopTerm ExprAddopTerm1, ExprAddopTerm ExprAddopTerm2) {
        this.ExprAddopTerm=ExprAddopTerm;
        if(ExprAddopTerm!=null) ExprAddopTerm.setParent(this);
        this.ExprAddopTerm1=ExprAddopTerm1;
        if(ExprAddopTerm1!=null) ExprAddopTerm1.setParent(this);
        this.ExprAddopTerm2=ExprAddopTerm2;
        if(ExprAddopTerm2!=null) ExprAddopTerm2.setParent(this);
    }

    public ExprAddopTerm getExprAddopTerm() {
        return ExprAddopTerm;
    }

    public void setExprAddopTerm(ExprAddopTerm ExprAddopTerm) {
        this.ExprAddopTerm=ExprAddopTerm;
    }

    public ExprAddopTerm getExprAddopTerm1() {
        return ExprAddopTerm1;
    }

    public void setExprAddopTerm1(ExprAddopTerm ExprAddopTerm1) {
        this.ExprAddopTerm1=ExprAddopTerm1;
    }

    public ExprAddopTerm getExprAddopTerm2() {
        return ExprAddopTerm2;
    }

    public void setExprAddopTerm2(ExprAddopTerm ExprAddopTerm2) {
        this.ExprAddopTerm2=ExprAddopTerm2;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ExprAddopTerm!=null) ExprAddopTerm.accept(visitor);
        if(ExprAddopTerm1!=null) ExprAddopTerm1.accept(visitor);
        if(ExprAddopTerm2!=null) ExprAddopTerm2.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ExprAddopTerm!=null) ExprAddopTerm.traverseTopDown(visitor);
        if(ExprAddopTerm1!=null) ExprAddopTerm1.traverseTopDown(visitor);
        if(ExprAddopTerm2!=null) ExprAddopTerm2.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ExprAddopTerm!=null) ExprAddopTerm.traverseBottomUp(visitor);
        if(ExprAddopTerm1!=null) ExprAddopTerm1.traverseBottomUp(visitor);
        if(ExprAddopTerm2!=null) ExprAddopTerm2.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("TernaryExpr(\n");

        if(ExprAddopTerm!=null)
            buffer.append(ExprAddopTerm.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ExprAddopTerm1!=null)
            buffer.append(ExprAddopTerm1.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ExprAddopTerm2!=null)
            buffer.append(ExprAddopTerm2.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [TernaryExpr]");
        return buffer.toString();
    }
}
