// generated with ast extension for cup
// version 0.8
// 7/1/2021 21:22:6


package rs.ac.bg.etf.pp1.ast;

public class ConstDeclMoreChar extends ConstDeclMore {

    private String charConstName;
    private Character C1;
    private ConstDeclMore ConstDeclMore;

    public ConstDeclMoreChar (String charConstName, Character C1, ConstDeclMore ConstDeclMore) {
        this.charConstName=charConstName;
        this.C1=C1;
        this.ConstDeclMore=ConstDeclMore;
        if(ConstDeclMore!=null) ConstDeclMore.setParent(this);
    }

    public String getCharConstName() {
        return charConstName;
    }

    public void setCharConstName(String charConstName) {
        this.charConstName=charConstName;
    }

    public Character getC1() {
        return C1;
    }

    public void setC1(Character C1) {
        this.C1=C1;
    }

    public ConstDeclMore getConstDeclMore() {
        return ConstDeclMore;
    }

    public void setConstDeclMore(ConstDeclMore ConstDeclMore) {
        this.ConstDeclMore=ConstDeclMore;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ConstDeclMore!=null) ConstDeclMore.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ConstDeclMore!=null) ConstDeclMore.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ConstDeclMore!=null) ConstDeclMore.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ConstDeclMoreChar(\n");

        buffer.append(" "+tab+charConstName);
        buffer.append("\n");

        buffer.append(" "+tab+C1);
        buffer.append("\n");

        if(ConstDeclMore!=null)
            buffer.append(ConstDeclMore.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ConstDeclMoreChar]");
        return buffer.toString();
    }
}
