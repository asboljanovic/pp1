// generated with ast extension for cup
// version 0.8
// 7/1/2021 21:22:6


package rs.ac.bg.etf.pp1.ast;

public class ConstDeclMoreNum extends ConstDeclMore {

    private String numConstName;
    private Integer N1;
    private ConstDeclMore ConstDeclMore;

    public ConstDeclMoreNum (String numConstName, Integer N1, ConstDeclMore ConstDeclMore) {
        this.numConstName=numConstName;
        this.N1=N1;
        this.ConstDeclMore=ConstDeclMore;
        if(ConstDeclMore!=null) ConstDeclMore.setParent(this);
    }

    public String getNumConstName() {
        return numConstName;
    }

    public void setNumConstName(String numConstName) {
        this.numConstName=numConstName;
    }

    public Integer getN1() {
        return N1;
    }

    public void setN1(Integer N1) {
        this.N1=N1;
    }

    public ConstDeclMore getConstDeclMore() {
        return ConstDeclMore;
    }

    public void setConstDeclMore(ConstDeclMore ConstDeclMore) {
        this.ConstDeclMore=ConstDeclMore;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ConstDeclMore!=null) ConstDeclMore.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ConstDeclMore!=null) ConstDeclMore.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ConstDeclMore!=null) ConstDeclMore.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ConstDeclMoreNum(\n");

        buffer.append(" "+tab+numConstName);
        buffer.append("\n");

        buffer.append(" "+tab+N1);
        buffer.append("\n");

        if(ConstDeclMore!=null)
            buffer.append(ConstDeclMore.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ConstDeclMoreNum]");
        return buffer.toString();
    }
}
