// generated with ast extension for cup
// version 0.8
// 7/1/2021 21:22:6


package rs.ac.bg.etf.pp1.ast;

public abstract class VisitorAdaptor implements Visitor { 

    public void visit(Unmatched Unmatched) { }
    public void visit(Mulop Mulop) { }
    public void visit(MethodDecl MethodDecl) { }
    public void visit(Matched Matched) { }
    public void visit(Relop Relop) { }
    public void visit(Assignop Assignop) { }
    public void visit(StatementList StatementList) { }
    public void visit(VarPart VarPart) { }
    public void visit(Addop Addop) { }
    public void visit(DeclListPart DeclListPart) { }
    public void visit(MethodDeclBrace MethodDeclBrace) { }
    public void visit(Factor Factor) { }
    public void visit(CondTerm CondTerm) { }
    public void visit(StatList StatList) { }
    public void visit(DeclList DeclList) { }
    public void visit(Designator Designator) { }
    public void visit(ExprAddopTerm ExprAddopTerm) { }
    public void visit(Term Term) { }
    public void visit(FormParsList FormParsList) { }
    public void visit(Condition Condition) { }
    public void visit(VarDeclRowPart VarDeclRowPart) { }
    public void visit(ExtendsDecl ExtendsDecl) { }
    public void visit(VarDeclRow VarDeclRow) { }
    public void visit(Expr2 Expr2) { }
    public void visit(Expr Expr) { }
    public void visit(Case Case) { }
    public void visit(Expr1 Expr1) { }
    public void visit(ConstDeclMore ConstDeclMore) { }
    public void visit(ActPars ActPars) { }
    public void visit(DesignatorStatement DesignatorStatement) { }
    public void visit(VarDeclLocal VarDeclLocal) { }
    public void visit(Statement Statement) { }
    public void visit(VarDecl VarDecl) { }
    public void visit(ClassDecl ClassDecl) { }
    public void visit(ConstDecl ConstDecl) { }
    public void visit(CondFact CondFact) { }
    public void visit(MethodDeclList MethodDeclList) { }
    public void visit(FormParsDecl FormParsDecl) { }
    public void visit(FormPars FormPars) { }
    public void visit(LocalVarDeclList LocalVarDeclList) { }
    public void visit(ModOperator ModOperator) { visit(); }
    public void visit(DivOperator DivOperator) { visit(); }
    public void visit(MulOperator MulOperator) { visit(); }
    public void visit(SubOperator SubOperator) { visit(); }
    public void visit(AddOperator AddOperator) { visit(); }
    public void visit(LessThanOrEqual LessThanOrEqual) { visit(); }
    public void visit(LessThanOp LessThanOp) { visit(); }
    public void visit(GreaterThanOrEqualOp GreaterThanOrEqualOp) { visit(); }
    public void visit(GreaterThanOp GreaterThanOp) { visit(); }
    public void visit(IfNotEquals IfNotEquals) { visit(); }
    public void visit(IfEqualsOp IfEqualsOp) { visit(); }
    public void visit(AssignOperator AssignOperator) { visit(); }
    public void visit(DesArrayName DesArrayName) { visit(); }
    public void visit(DesignatorExpr DesignatorExpr) { visit(); }
    public void visit(DesignatorDot DesignatorDot) { visit(); }
    public void visit(DesignatorSingle DesignatorSingle) { visit(); }
    public void visit(FactorExpr FactorExpr) { visit(); }
    public void visit(FactorNewTypeWithExpr FactorNewTypeWithExpr) { visit(); }
    public void visit(FactorNewType FactorNewType) { visit(); }
    public void visit(FactorBoolConst FactorBoolConst) { visit(); }
    public void visit(FactorCharConst FactorCharConst) { visit(); }
    public void visit(FactorNumConst FactorNumConst) { visit(); }
    public void visit(FactorDesignatorWithParams FactorDesignatorWithParams) { visit(); }
    public void visit(FactorDesignatorNoParams FactorDesignatorNoParams) { visit(); }
    public void visit(FactorDesignator FactorDesignator) { visit(); }
    public void visit(TermFactor TermFactor) { visit(); }
    public void visit(TermMulop TermMulop) { visit(); }
    public void visit(TermExpr TermExpr) { visit(); }
    public void visit(SubTermExpr SubTermExpr) { visit(); }
    public void visit(ExprAddopTermDecl ExprAddopTermDecl) { visit(); }
    public void visit(Expr2Decl Expr2Decl) { visit(); }
    public void visit(Expr1Decl Expr1Decl) { visit(); }
    public void visit(TernaryExpr TernaryExpr) { visit(); }
    public void visit(AddopTermExpr AddopTermExpr) { visit(); }
    public void visit(CondFactTwoExpr CondFactTwoExpr) { visit(); }
    public void visit(CondFactSingleExpr CondFactSingleExpr) { visit(); }
    public void visit(ConditionTermSingle ConditionTermSingle) { visit(); }
    public void visit(ConditionTerm ConditionTerm) { visit(); }
    public void visit(ConditionSingle ConditionSingle) { visit(); }
    public void visit(ConditionDecl ConditionDecl) { visit(); }
    public void visit(ActualParametersSingle ActualParametersSingle) { visit(); }
    public void visit(ActualParametersComma ActualParametersComma) { visit(); }
    public void visit(DesignatorDec DesignatorDec) { visit(); }
    public void visit(DesignatorInc DesignatorInc) { visit(); }
    public void visit(DesignatorWithActPars DesignatorWithActPars) { visit(); }
    public void visit(DesignatorNoActPars DesignatorNoActPars) { visit(); }
    public void visit(DesignatorAssign DesignatorAssign) { visit(); }
    public void visit(NoCase NoCase) { visit(); }
    public void visit(CaseDecl CaseDecl) { visit(); }
    public void visit(Statements Statements) { visit(); }
    public void visit(PrintStatementWithComma PrintStatementWithComma) { visit(); }
    public void visit(PrintStatement PrintStatement) { visit(); }
    public void visit(ReadStatement ReadStatement) { visit(); }
    public void visit(ReturnStatement ReturnStatement) { visit(); }
    public void visit(ContinueStatement ContinueStatement) { visit(); }
    public void visit(BreakStatement BreakStatement) { visit(); }
    public void visit(SwitchStatement SwitchStatement) { visit(); }
    public void visit(DoWhileStatement DoWhileStatement) { visit(); }
    public void visit(ErrorStmt ErrorStmt) { visit(); }
    public void visit(AssignmentsStatement AssignmentsStatement) { visit(); }
    public void visit(UnmatchedIfElse UnmatchedIfElse) { visit(); }
    public void visit(UnmatchedIf UnmatchedIf) { visit(); }
    public void visit(UnmatchedStatement UnmatchedStatement) { visit(); }
    public void visit(MatchedStatement MatchedStatement) { visit(); }
    public void visit(SingleStatement SingleStatement) { visit(); }
    public void visit(StatementListMore StatementListMore) { visit(); }
    public void visit(NoStatements NoStatements) { visit(); }
    public void visit(StatementListDecl StatementListDecl) { visit(); }
    public void visit(Type Type) { visit(); }
    public void visit(FormParamArray FormParamArray) { visit(); }
    public void visit(FormParam FormParam) { visit(); }
    public void visit(FormalParametersDecl FormalParametersDecl) { visit(); }
    public void visit(FormalParametersList FormalParametersList) { visit(); }
    public void visit(NoFormalParameters NoFormalParameters) { visit(); }
    public void visit(FormalParameters FormalParameters) { visit(); }
    public void visit(NoMethodDeclarationsBrace NoMethodDeclarationsBrace) { visit(); }
    public void visit(MethodDeclarationsBrace MethodDeclarationsBrace) { visit(); }
    public void visit(NoMethodDeclarationList NoMethodDeclarationList) { visit(); }
    public void visit(MethodDeclarationList MethodDeclarationList) { visit(); }
    public void visit(MethodTypeNameVoid MethodTypeNameVoid) { visit(); }
    public void visit(MethodTypeName MethodTypeName) { visit(); }
    public void visit(MethodDeclarationVoid MethodDeclarationVoid) { visit(); }
    public void visit(MethodDeclaration MethodDeclaration) { visit(); }
    public void visit(NoExtends NoExtends) { visit(); }
    public void visit(ExtendsDeclaration ExtendsDeclaration) { visit(); }
    public void visit(ClassDeclaration ClassDeclaration) { visit(); }
    public void visit(SingleVarDeclLocal SingleVarDeclLocal) { visit(); }
    public void visit(VarDeclLocalList VarDeclLocalList) { visit(); }
    public void visit(NoVarDecl NoVarDecl) { visit(); }
    public void visit(VarDeclarations VarDeclarations) { visit(); }
    public void visit(ErrorStmt2 ErrorStmt2) { visit(); }
    public void visit(VarDeclarationPartArray VarDeclarationPartArray) { visit(); }
    public void visit(VarDeclarationPart VarDeclarationPart) { visit(); }
    public void visit(SingleVarDeclaration SingleVarDeclaration) { visit(); }
    public void visit(VarDeclarationRow VarDeclarationRow) { visit(); }
    public void visit(ErrorStmt1 ErrorStmt1) { visit(); }
    public void visit(VarDeclaration VarDeclaration) { visit(); }
    public void visit(NoMoreConstDecl NoMoreConstDecl) { visit(); }
    public void visit(ConstDeclMoreBool ConstDeclMoreBool) { visit(); }
    public void visit(ConstDeclMoreChar ConstDeclMoreChar) { visit(); }
    public void visit(ConstDeclMoreNum ConstDeclMoreNum) { visit(); }
    public void visit(ConstDeclBool ConstDeclBool) { visit(); }
    public void visit(ConstDeclChar ConstDeclChar) { visit(); }
    public void visit(ConstDeclNum ConstDeclNum) { visit(); }
    public void visit(ClassDeclarationListPart ClassDeclarationListPart) { visit(); }
    public void visit(VarDeclarationListPart VarDeclarationListPart) { visit(); }
    public void visit(ConstDeclarationListPart ConstDeclarationListPart) { visit(); }
    public void visit(NoDeclarations NoDeclarations) { visit(); }
    public void visit(Declarations Declarations) { visit(); }
    public void visit(ProgName ProgName) { visit(); }
    public void visit(Program Program) { visit(); }


    public void visit() { }
}
